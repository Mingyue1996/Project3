1. When player vs computer, player starts first
2. Player�s user name cannot be Computer. 
3. The user name entered by the player cannot be found in the list; otherwise, you will see error prompts.
4. Once users choose to use a previous username, they have to use the previous marker as well even if they enter a new marker.
5. Click on �quit� to save game results permanently. If you click on the �close� button on the top right of the UI, then game results will not be permanently saved.
6. Most Important: Check the image I put called directory in the file to put all the files in correct positions. You might need to create a JavaFX project first in eclipse. This �directory� image has nothing to do with my project. The worst case is to go to my github to make everything work: https://github.com/Mingyue1996/Project3
7. I only have sounds for win/loss. No animation. No sound for a tie. The professor said it is OK.
8. Important: You have to click on the button �Choose user name� each time you choose a user name. If you see a list, but you don�t click on the button �Choose user name�, the project might not work.
9. You might not see �it is Computer�s� turn because this label changes very fast and you cannot see it. This is not an error.
10. cn.png, gb.png, us.png are all considered as images.

