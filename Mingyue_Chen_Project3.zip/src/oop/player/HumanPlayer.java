package oop.player;


public class HumanPlayer extends Player {
	
	public HumanPlayer(String username, String marker, int playerID) {
		super.username = username;
		super.marker = marker;
		super.playerID = playerID;
	}
	
}