1. When player vs computer, player starts first
2. Player�s user name cannot be Computer. If you enter �Computer�, the program will ignore the input and assume the user does not enter a user name.
3. The user name entered by the player cannot be found in the list.
4. Once users choose to use a previous username, they have to use the previous marker as well even if they enter a new marker.
5. Click on �quit� to save game results permanently. If you click on the �close� button on the top right of the UI, then game results will not be permanently saved.
6. Most Important: When you test my code, please make sure create a JavaFX project (let�s say its name is Project3). Under Project3, replace the src folder with my src folder. Put all the sound and images files outside src folder but inside Project3 folder. Do not remove userInfo.ser. Put userInfo.ser outside src but inside Project3.
